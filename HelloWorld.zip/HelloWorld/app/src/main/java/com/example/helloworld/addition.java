package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class addition extends AppCompatActivity {

    EditText editText,editText2;
    TextView textView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addition);


        editText = (EditText) findViewById(R.id.editText);
        editText2 = (EditText) findViewById(R.id.editText2);
        textView = (TextView) findViewById(R.id.textView);
        button = (Button) findViewById(R.id.button);


    }


    public void add (View v)
    {
        System.out.println("Hello");
        int i=Integer.parseInt(editText.getText().toString());
        int j=Integer.parseInt(editText2.getText().toString());
        int k =i+j;

        textView.setText("Ans is  "+ k);

    }

}
