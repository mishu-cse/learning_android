package com.example.logindemoexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ShowActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String email = intent.getStringExtra("email");
        String pass = intent.getStringExtra("pass");

        String val= name +" "+ email + " " + pass;
        System.out.println("show value##########################################################"+val);

        // Capture the layout's TextView and set the string as its text
        TextView textView_name = findViewById(R.id.name);
        textView_name.setText(name);

        TextView textView_email = findViewById(R.id.email);
        textView_email.setText(email);

        TextView textView_pass = findViewById(R.id.pass);
        textView_pass.setText(pass);
    }
}
