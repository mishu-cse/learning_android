package com.example.logindemoexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    Button btnLogin;
    EditText editName,editEmail, editPassword;
    RadioGroup radioGroup;
    RadioButton r1,r2;
    String sex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        editName  = (EditText) findViewById(R.id.name);
        editEmail  = (EditText) findViewById(R.id.email);
        editPassword = (EditText) findViewById(R.id.password);

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);

        r1 = (RadioButton) findViewById(R.id.radio_one);
        r2 = (RadioButton) findViewById(R.id.radio_two);

        btnLogin = (Button)findViewById(R.id.login_button);
        btnLogin.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {

                String name = editName.getText().toString();
                String email = editEmail.getText().toString();
                String password = editPassword.getText().toString();

                if(r1.isChecked())
                    sex ="Male";
                else if(r2.isChecked())
                    sex ="Female";

                String val= name +" "+ email + " " + password + " "+ sex;
                System.out.println(val);

                /*
              // Do something in response to button click
                Toast toast = Toast.makeText(SignUpActivity.this,
                        val,Toast.LENGTH_SHORT);
                toast.show();
                */

                // Go to next page
                Intent intent = new Intent(SignUpActivity.this, ShowActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("email", email);
                intent.putExtra("pass", password);
                startActivity(intent);
            }
        });
    }
}
